(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_049fj~5._.js","static/chunks/node_modules_0hk9wkk._.js"],
    source: "dynamic"
});
