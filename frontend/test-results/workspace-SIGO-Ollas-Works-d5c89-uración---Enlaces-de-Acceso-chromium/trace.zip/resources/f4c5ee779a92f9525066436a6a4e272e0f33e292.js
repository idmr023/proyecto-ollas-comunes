(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0t8~q_c._.css","static/chunks/node_modules_0jsnfqp._.js","static/chunks/src_05_7kt~._.js"],
    source: "dynamic"
});
