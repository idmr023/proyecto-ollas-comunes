(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/ui/skeleton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Skeleton",
    ()=>Skeleton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
;
;
function Skeleton({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "skeleton",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("animate-pulse rounded-md bg-muted", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/skeleton.tsx",
        lineNumber: 5,
        columnNumber: 5
    }, this);
}
_c = Skeleton;
;
var _c;
__turbopack_context__.k.register(_c, "Skeleton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/use-api.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useApi",
    ()=>useApi
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/auth-store.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/indexed-db.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const BASE_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL ?? "http://localhost:4000";
// Helper para manejar las mutaciones optimistas fuera del hook
async function handleOfflineMutation(endpoint, opts) {
    const method = (opts.method ?? "POST").toUpperCase();
    const body = opts.body ? JSON.parse(opts.body) : null;
    // Generar ID temporal si es creación
    const tempId = method === "POST" ? `temp-${Math.floor(100000 + Math.random() * 900000)}` : undefined;
    console.log("[useApi Offline] Encolando cambio offline en useApi:", method, endpoint, body, "tempId:", tempId);
    // Encolar mutación en IndexedDB
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addMutation"])(endpoint, method, body, tempId);
    // 1. Manejo optimista de beneficiarios
    if (endpoint.startsWith("/api/beneficiaries")) {
        const cachedList = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCache"])("/api/beneficiaries");
        if (cachedList && Array.isArray(cachedList.items)) {
            let updatedItems = [
                ...cachedList.items
            ];
            if (method === "POST" && tempId) {
                const mockBeneficiary = {
                    id: tempId,
                    firstName: body?.firstName ?? "",
                    lastName: body?.lastName ?? "",
                    fullName: `${body?.firstName ?? ""} ${body?.lastName ?? ""}`.trim(),
                    dni: body?.dni ?? "",
                    birthDate: body?.birthDate ?? "",
                    gender: body?.gender ?? "not_specified",
                    phone: body?.phone ?? "",
                    address: body?.address ?? "",
                    ollaId: body?.ollaId ?? null,
                    priorityLevel: body?.priorityLevel ?? "normal",
                    status: body?.status ?? "active",
                    registeredAt: new Date().toISOString(),
                    olla: null,
                    healthConditions: (body?.healthConditionIds ?? []).map((id)=>({
                            id,
                            name: id === 1 ? "Diabetes" : id === 2 ? "Hipertensión" : "Condición"
                        })),
                    offline: true
                };
                updatedItems.unshift(mockBeneficiary);
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setCache"])("/api/beneficiaries", {
                    ...cachedList,
                    items: updatedItems
                });
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success("Operación registrada localmente. Se sincronizará al volver a estar en línea.");
                return {
                    ok: true,
                    item: mockBeneficiary
                };
            } else if (method === "PATCH") {
                const idToUpdate = endpoint.split("/").pop();
                updatedItems = updatedItems.map((item)=>item.id === idToUpdate ? {
                        ...item,
                        ...body,
                        fullName: `${body?.firstName ?? item.firstName} ${body?.lastName ?? item.lastName}`.trim()
                    } : item);
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setCache"])("/api/beneficiaries", {
                    ...cachedList,
                    items: updatedItems
                });
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success("Cambios guardados localmente.");
                return {
                    ok: true
                };
            } else if (method === "DELETE") {
                const idToDelete = endpoint.split("/").pop();
                updatedItems = updatedItems.filter((item)=>item.id !== idToDelete);
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setCache"])("/api/beneficiaries", {
                    ...cachedList,
                    items: updatedItems
                });
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success("Eliminación registrada localmente.");
                return {
                    ok: true
                };
            }
        }
    }
    // 2. Manejo optimista de entrega de raciones
    if (endpoint.startsWith("/api/mobile/deliveries")) {
        const beneficiaryIds = Array.isArray(body?.beneficiaryIds) ? body.beneficiaryIds : [];
        // Marcar beneficiarios como hasEatenToday
        const cachedList = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCache"])("/api/beneficiaries");
        if (cachedList && Array.isArray(cachedList.items)) {
            const updatedItems = cachedList.items.map((b)=>beneficiaryIds.includes(b.id) ? {
                    ...b,
                    hasEatenToday: true
                } : b);
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setCache"])("/api/beneficiaries", {
                ...cachedList,
                items: updatedItems
            });
        }
        // Actualizar sumario diario en Dashboard
        const cachedDashboard = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCache"])("/api/mobile/dashboard");
        if (cachedDashboard) {
            const count = beneficiaryIds.length || Number(body?.totalRations) || 1;
            const updatedDashboard = {
                ...cachedDashboard,
                summary: {
                    ...cachedDashboard.summary,
                    entregadas: (cachedDashboard.summary?.entregadas ?? 0) + count,
                    menu: cachedDashboard.summary?.menu ? {
                        ...cachedDashboard.summary.menu,
                        status: "executed",
                        maxServingsRemaining: Math.max(0, (cachedDashboard.summary.menu.maxServingsRemaining ?? 0) - count)
                    } : null
                }
            };
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setCache"])("/api/mobile/dashboard", updatedDashboard);
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success("Entrega de raciones registrada localmente.");
        // Despachar evento para alertar
        if ("TURBOPACK compile-time truthy", 1) {
            window.dispatchEvent(new Event("offline-mutations-updated"));
        }
        return {
            ok: true,
            delivery: {
                id: `temp-del-${Date.now()}`,
                beneficiaryIds,
                dishName: body?.dishName
            }
        };
    }
    // 3. Manejo optimista de ejecución de planes de menú
    if (endpoint.startsWith("/api/mobile/menu-plans/execute")) {
        const dishName = body?.dishName || "Menú del día";
        const servings = Number(body?.servings) || 100;
        const cachedDashboard = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCache"])("/api/mobile/dashboard");
        if (cachedDashboard) {
            const updatedDashboard = {
                ...cachedDashboard,
                summary: {
                    ...cachedDashboard.summary,
                    menu: {
                        dishName,
                        status: "executed",
                        maxServingsRemaining: servings
                    }
                }
            };
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setCache"])("/api/mobile/dashboard", updatedDashboard);
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success("Plan de menú ejecutado localmente.");
        if ("TURBOPACK compile-time truthy", 1) {
            window.dispatchEvent(new Event("offline-mutations-updated"));
        }
        return {
            ok: true,
            plan: {
                id: `temp-plan-${Date.now()}`,
                dishName,
                servings
            }
        };
    }
    // 4. Manejo optimista de movimientos de inventario
    if (endpoint.startsWith("/api/mobile/inventory/movements")) {
        const supplyItemId = body?.supplyItemId;
        const movementType = body?.movementType;
        const quantity = Number(body?.quantity) || 0;
        const cachedInventory = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCache"])("/api/mobile/inventory");
        if (cachedInventory && Array.isArray(cachedInventory.items)) {
            const updatedItems = cachedInventory.items.map((item)=>{
                if (item.id === supplyItemId) {
                    const currentQty = Number(item.cantidad) || 0;
                    const delta = movementType === "in" ? quantity : -quantity;
                    const newQty = Math.max(0, currentQty + delta);
                    return {
                        ...item,
                        cantidad: newQty
                    };
                }
                return item;
            });
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setCache"])("/api/mobile/inventory", {
                ...cachedInventory,
                items: updatedItems
            });
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success("Movimiento de inventario registrado localmente.");
        if ("TURBOPACK compile-time truthy", 1) {
            window.dispatchEvent(new Event("offline-mutations-updated"));
        }
        return {
            ok: true,
            movement: {
                id: `temp-mov-${Date.now()}`,
                ...body
            }
        };
    }
    // Fallback genérico para mutaciones offline
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success("Operación registrada localmente.");
    if ("TURBOPACK compile-time truthy", 1) {
        window.dispatchEvent(new Event("offline-mutations-updated"));
    }
    return {
        ok: true,
        message: "Operación registrada localmente."
    };
}
function useApi() {
    _s();
    const token = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"])({
        "useApi.useAuthStore[token]": (s)=>s.token
    }["useApi.useAuthStore[token]"]);
    const clearAuth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"])({
        "useApi.useAuthStore[clearAuth]": (s)=>s.clearAuth
    }["useApi.useAuthStore[clearAuth]"]);
    const request = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useApi.useCallback[request]": async (endpoint, opts = {})=>{
            const { params, ...fetchOpts } = opts;
            const url = new URL(`${BASE_URL}${endpoint}`);
            if (params) Object.entries(params).forEach({
                "useApi.useCallback[request]": ([k, v])=>url.searchParams.set(k, v)
            }["useApi.useCallback[request]"]);
            // Crear la llave de caché única para este endpoint
            const cacheKey = endpoint + (params && Object.keys(params).length > 0 ? "?" + new URLSearchParams(params).toString() : "");
            const isGet = !fetchOpts.method || fetchOpts.method.toUpperCase() === "GET";
            const isOffline = ("TURBOPACK compile-time value", "object") !== "undefined" && !navigator.onLine;
            if (isOffline) {
                if (isGet) {
                    const cached = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCache"])(cacheKey);
                    if (cached) {
                        console.log("[useApi] Servido desde caché local (offline):", cacheKey);
                        return cached;
                    }
                    throw new Error("Sin conexión. No hay datos locales guardados para esta vista.");
                } else {
                    return await handleOfflineMutation(endpoint, fetchOpts);
                }
            }
            const headers = {
                "Content-Type": "application/json",
                ...fetchOpts.headers
            };
            if (token) headers["Authorization"] = `Bearer ${token}`;
            try {
                const res = await fetch(url.toString(), {
                    ...fetchOpts,
                    headers
                });
                if (res.status === 401 && navigator.onLine) {
                    clearAuth();
                    if ("TURBOPACK compile-time truthy", 1) window.location.href = "/login";
                    throw new Error("Sesión expirada. Ingresa nuevamente.");
                }
                if (res.status === 401) {
                    throw new Error("Sin conexión. No se pudo validar la sesión.");
                }
                if (!res.ok) {
                    const body = await res.json().catch({
                        "useApi.useCallback[request]": ()=>({})
                    }["useApi.useCallback[request]"]);
                    throw new Error(body.message ?? body.error ?? `Error ${res.status}`);
                }
                const data = await res.json();
                // Si la petición GET fue exitosa online, guardarla en caché local
                if (isGet) {
                    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setCache"])(cacheKey, data);
                }
                return data;
            } catch (err) {
                // En caso de fallo de red real (ej. servidor caído o timeout)
                if (isGet) {
                    const cached = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCache"])(cacheKey);
                    if (cached) {
                        console.log("[useApi] Fallo de red. Sirviendo desde caché local:", cacheKey);
                        return cached;
                    }
                } else if (err instanceof TypeError && err.message === "Failed to fetch") {
                    // Si falla fetch en una mutación, registrar localmente
                    return await handleOfflineMutation(endpoint, fetchOpts);
                }
                if (err instanceof TypeError && err.message === "Failed to fetch") {
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Sin conexión. Revisa tu red e intenta de nuevo.");
                    throw new Error("Sin conexión al servidor");
                }
                throw err;
            }
        }
    }["useApi.useCallback[request]"], [
        token,
        clearAuth
    ]);
    const get = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useApi.useCallback[get]": (endpoint, params)=>request(endpoint, {
                params
            })
    }["useApi.useCallback[get]"], [
        request
    ]);
    return {
        request,
        get
    };
}
_s(useApi, "rUBNZTBTR+a4xjWRFXMoBwCmXps=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/mobile/alertas/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AlertasPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$triangle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertTriangle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/triangle-alert.js [app-client] (ecmascript) <export default as AlertTriangle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/clock.js [app-client] (ecmascript) <export default as Clock>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wifi$2d$off$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__WifiOff$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/wifi-off.js [app-client] (ecmascript) <export default as WifiOff>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$package$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Package$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/package.js [app-client] (ecmascript) <export default as Package>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/skeleton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/use-api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
function AlertasPage() {
    _s();
    const { get } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApi"])();
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [alertas, setAlertas] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const fetchAlertas = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AlertasPage.useCallback[fetchAlertas]": async ()=>{
            try {
                const data = await get("/api/mobile/alerts");
                setAlertas(data.items ?? []);
            } catch (err) {
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Error al cargar alertas");
            } finally{
                setLoading(false);
            }
        }
    }["AlertasPage.useCallback[fetchAlertas]"], [
        get
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AlertasPage.useEffect": ()=>{
            fetchAlertas();
        }
    }["AlertasPage.useEffect"], [
        fetchAlertas
    ]);
    const icono = (tipo)=>{
        switch(tipo){
            case "vencimiento":
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__["Clock"];
            case "bajo_stock":
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$package$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Package$3e$__["Package"];
            case "sincronizacion":
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wifi$2d$off$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__WifiOff$3e$__["WifiOff"];
            default:
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$triangle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertTriangle$3e$__["AlertTriangle"];
        }
    };
    const color = (tipo)=>{
        switch(tipo){
            case "vencimiento":
                return "border-highlight bg-highlight/10";
            case "bajo_stock":
                return "border-destructive bg-destructive/10";
            case "sincronizacion":
                return "border-status-pending/30 bg-status-pending/10";
            default:
                return "border-border bg-muted";
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-4 p-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-xl font-bold text-foreground",
                                children: "Alertas"
                            }, void 0, false, {
                                fileName: "[project]/src/app/mobile/alertas/page.tsx",
                                lineNumber: 61,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm text-muted-foreground",
                                children: [
                                    alertas.length,
                                    " notificaciones"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/mobile/alertas/page.tsx",
                                lineNumber: 62,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/mobile/alertas/page.tsx",
                        lineNumber: 60,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$triangle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertTriangle$3e$__["AlertTriangle"], {
                        className: "h-6 w-6 text-highlight-foreground"
                    }, void 0, false, {
                        fileName: "[project]/src/app/mobile/alertas/page.tsx",
                        lineNumber: 64,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/mobile/alertas/page.tsx",
                lineNumber: 59,
                columnNumber: 7
            }, this),
            loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-3",
                children: [
                    1,
                    2,
                    3
                ].map((i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Skeleton"], {
                        className: "h-[72px] rounded-xl"
                    }, i, false, {
                        fileName: "[project]/src/app/mobile/alertas/page.tsx",
                        lineNumber: 69,
                        columnNumber: 33
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/app/mobile/alertas/page.tsx",
                lineNumber: 68,
                columnNumber: 9
            }, this) : alertas.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col items-center py-16 text-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$triangle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertTriangle$3e$__["AlertTriangle"], {
                        className: "mb-3 h-12 w-12 text-muted-foreground/30"
                    }, void 0, false, {
                        fileName: "[project]/src/app/mobile/alertas/page.tsx",
                        lineNumber: 73,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-muted-foreground",
                        children: "No hay alertas pendientes"
                    }, void 0, false, {
                        fileName: "[project]/src/app/mobile/alertas/page.tsx",
                        lineNumber: 74,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/mobile/alertas/page.tsx",
                lineNumber: 72,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-3",
                children: alertas.map((a)=>{
                    const Icon = icono(a.tipo);
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/mobile/inventario",
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex items-start gap-3 rounded-xl border p-4 transition active:scale-[0.98]", color(a.tipo)),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                className: "mt-0.5 h-5 w-5 shrink-0"
                            }, void 0, false, {
                                fileName: "[project]/src/app/mobile/alertas/page.tsx",
                                lineNumber: 86,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "min-w-0 flex-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm font-semibold text-foreground",
                                        children: a.titulo
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/mobile/alertas/page.tsx",
                                        lineNumber: 88,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xs text-muted-foreground",
                                        children: a.descripcion
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/mobile/alertas/page.tsx",
                                        lineNumber: 89,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/mobile/alertas/page.tsx",
                                lineNumber: 87,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "shrink-0 text-[10px] font-medium uppercase text-muted-foreground",
                                children: a.fecha
                            }, void 0, false, {
                                fileName: "[project]/src/app/mobile/alertas/page.tsx",
                                lineNumber: 91,
                                columnNumber: 17
                            }, this)
                        ]
                    }, a.id, true, {
                        fileName: "[project]/src/app/mobile/alertas/page.tsx",
                        lineNumber: 81,
                        columnNumber: 15
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/src/app/mobile/alertas/page.tsx",
                lineNumber: 77,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/mobile/alertas/page.tsx",
        lineNumber: 58,
        columnNumber: 5
    }, this);
}
_s(AlertasPage, "88lZVxJ46D5CyQgj8vccq9DP7Og=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApi"]
    ];
});
_c = AlertasPage;
var _c;
__turbopack_context__.k.register(_c, "AlertasPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/lucide-react/dist/esm/icons/clock.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Clock
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "circle",
        {
            cx: "12",
            cy: "12",
            r: "10",
            key: "1mglay"
        }
    ],
    [
        "path",
        {
            d: "M12 6v6l4 2",
            key: "mmk7yg"
        }
    ]
];
const Clock = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("clock", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/clock.js [app-client] (ecmascript) <export default as Clock>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Clock",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/clock.js [app-client] (ecmascript)");
}),
]);

//# sourceMappingURL=_02_4c-b._.js.map