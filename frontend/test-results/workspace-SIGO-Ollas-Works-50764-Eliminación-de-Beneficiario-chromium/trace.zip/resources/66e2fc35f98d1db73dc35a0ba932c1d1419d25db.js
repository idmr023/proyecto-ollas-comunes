(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_00ax5.w._.js","static/chunks/node_modules_0tw~~u1._.js"],
    source: "dynamic"
});
