(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_0jxstym._.js","static/chunks/node_modules_0ys~ow~._.js"],
    source: "dynamic"
});
