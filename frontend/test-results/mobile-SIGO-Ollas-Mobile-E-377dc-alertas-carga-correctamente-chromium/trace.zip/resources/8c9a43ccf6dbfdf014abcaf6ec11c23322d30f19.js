(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/ui/skeleton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Skeleton",
    ()=>Skeleton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
;
;
function Skeleton({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "skeleton",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("animate-pulse rounded-md bg-muted", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/skeleton.tsx",
        lineNumber: 5,
        columnNumber: 5
    }, this);
}
_c = Skeleton;
;
var _c;
__turbopack_context__.k.register(_c, "Skeleton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/use-api.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useApi",
    ()=>useApi
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/auth-store.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/indexed-db.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const BASE_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL ?? "http://localhost:4000";
function generateTempId() {
    return `temp-${Math.floor(100000 + Math.random() * 900000)}`;
}
function buildUrl(endpoint, params) {
    const url = new URL(`${BASE_URL}${endpoint}`);
    if (params) {
        for (const [k, v] of Object.entries(params)){
            url.searchParams.set(k, v);
        }
    }
    return url;
}
function buildCacheKey(endpoint, params) {
    if (!params || Object.keys(params).length === 0) return endpoint;
    return `${endpoint}?${new URLSearchParams(params).toString()}`;
}
function isGetRequest(method) {
    return !method || method.toUpperCase() === "GET";
}
function isOnline() {
    return typeof navigator === "undefined" || navigator.onLine;
}
function buildRequestHeaders(fetchOpts, token) {
    const customHeaders = fetchOpts.headers && typeof fetchOpts.headers === "object" && !Array.isArray(fetchOpts.headers) ? fetchOpts.headers : {};
    return {
        "Content-Type": "application/json",
        ...customHeaders,
        ...token ? {
            Authorization: `Bearer ${token}`
        } : {}
    };
}
function notifyOfflineMutationsUpdated() {
    if ("TURBOPACK compile-time truthy", 1) {
        window.dispatchEvent(new Event("offline-mutations-updated"));
    }
}
function buildMockBeneficiary(body, tempId) {
    return {
        id: tempId,
        firstName: body?.firstName ?? "",
        lastName: body?.lastName ?? "",
        fullName: `${body?.firstName ?? ""} ${body?.lastName ?? ""}`.trim(),
        dni: body?.dni ?? "",
        birthDate: body?.birthDate ?? "",
        gender: body?.gender ?? "not_specified",
        phone: body?.phone ?? "",
        address: body?.address ?? "",
        ollaId: body?.ollaId ?? null,
        priorityLevel: body?.priorityLevel ?? "normal",
        status: body?.status ?? "active",
        registeredAt: new Date().toISOString(),
        olla: null,
        healthConditions: (body?.healthConditionIds ?? []).map((id)=>({
                id,
                name: id === 1 ? "Diabetes" : id === 2 ? "Hipertensión" : "Condición"
            })),
        offline: true
    };
}
async function applyBeneficiariesOptimistic(method, endpoint, body, tempId) {
    if (!endpoint.startsWith("/api/beneficiaries")) return null;
    const cachedList = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCache"])("/api/beneficiaries");
    if (!cachedList || !Array.isArray(cachedList.items)) return null;
    if (method === "POST" && tempId) {
        const mockBeneficiary = buildMockBeneficiary(body, tempId);
        const updatedItems = [
            mockBeneficiary,
            ...cachedList.items
        ];
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setCache"])("/api/beneficiaries", {
            ...cachedList,
            items: updatedItems
        });
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success("Operación registrada localmente. Se sincronizará al volver a estar en línea.");
        return {
            ok: true,
            item: mockBeneficiary
        };
    }
    if (method === "PATCH") {
        const idToUpdate = endpoint.split("/").pop();
        const updatedItems = cachedList.items.map((item)=>item.id === idToUpdate ? {
                ...item,
                ...body,
                fullName: `${body?.firstName ?? item.firstName} ${body?.lastName ?? item.lastName}`.trim()
            } : item);
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setCache"])("/api/beneficiaries", {
            ...cachedList,
            items: updatedItems
        });
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success("Cambios guardados localmente.");
        return {
            ok: true
        };
    }
    if (method === "DELETE") {
        const idToDelete = endpoint.split("/").pop();
        const updatedItems = cachedList.items.filter((item)=>item.id !== idToDelete);
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setCache"])("/api/beneficiaries", {
            ...cachedList,
            items: updatedItems
        });
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success("Eliminación registrada localmente.");
        return {
            ok: true
        };
    }
    return null;
}
async function applyDeliveriesOptimistic(body) {
    const beneficiaryIds = Array.isArray(body?.beneficiaryIds) ? body.beneficiaryIds : [];
    const cachedList = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCache"])("/api/beneficiaries");
    if (cachedList && Array.isArray(cachedList.items)) {
        const updatedItems = cachedList.items.map((b)=>beneficiaryIds.includes(b.id) ? {
                ...b,
                hasEatenToday: true
            } : b);
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setCache"])("/api/beneficiaries", {
            ...cachedList,
            items: updatedItems
        });
    }
    const cachedDashboard = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCache"])("/api/mobile/dashboard");
    if (cachedDashboard) {
        const count = beneficiaryIds.length || Number(body?.totalRations) || 1;
        const updatedDashboard = {
            ...cachedDashboard,
            summary: {
                ...cachedDashboard.summary,
                entregadas: (cachedDashboard.summary?.entregadas ?? 0) + count,
                menu: cachedDashboard.summary?.menu ? {
                    ...cachedDashboard.summary.menu,
                    status: "executed",
                    maxServingsRemaining: Math.max(0, (cachedDashboard.summary.menu.maxServingsRemaining ?? 0) - count)
                } : null
            }
        };
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setCache"])("/api/mobile/dashboard", updatedDashboard);
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success("Entrega de raciones registrada localmente.");
    notifyOfflineMutationsUpdated();
    return {
        ok: true,
        delivery: {
            id: `temp-del-${Date.now()}`,
            beneficiaryIds,
            dishName: body?.dishName
        }
    };
}
async function applyMenuPlansOptimistic(body) {
    const dishName = body?.dishName || "Menú del día";
    const servings = Number(body?.servings) || 100;
    const cachedDashboard = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCache"])("/api/mobile/dashboard");
    if (cachedDashboard) {
        const updatedDashboard = {
            ...cachedDashboard,
            summary: {
                ...cachedDashboard.summary,
                menu: {
                    dishName,
                    status: "executed",
                    maxServingsRemaining: servings
                }
            }
        };
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setCache"])("/api/mobile/dashboard", updatedDashboard);
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success("Plan de menú ejecutado localmente.");
    notifyOfflineMutationsUpdated();
    return {
        ok: true,
        plan: {
            id: `temp-plan-${Date.now()}`,
            dishName,
            servings
        }
    };
}
async function applyInventoryOptimistic(body) {
    const supplyItemId = body?.supplyItemId;
    const movementType = body?.movementType;
    const quantity = Number(body?.quantity) || 0;
    const cachedInventory = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCache"])("/api/mobile/inventory");
    if (cachedInventory && Array.isArray(cachedInventory.items)) {
        const updatedItems = cachedInventory.items.map((item)=>{
            if (item.id === supplyItemId) {
                const currentQty = Number(item.cantidad) || 0;
                const delta = movementType === "in" ? quantity : -quantity;
                const newQty = Math.max(0, currentQty + delta);
                return {
                    ...item,
                    cantidad: newQty
                };
            }
            return item;
        });
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setCache"])("/api/mobile/inventory", {
            ...cachedInventory,
            items: updatedItems
        });
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success("Movimiento de inventario registrado localmente.");
    notifyOfflineMutationsUpdated();
    return {
        ok: true,
        movement: {
            id: `temp-mov-${Date.now()}`,
            ...body
        }
    };
}
async function handleOfflineMutation(endpoint, opts) {
    const method = (opts.method ?? "POST").toUpperCase();
    const body = opts.body ? JSON.parse(opts.body) : null;
    const tempId = method === "POST" ? generateTempId() : undefined;
    console.log("[useApi Offline] Encolando cambio offline en useApi:", method, endpoint, body, "tempId:", tempId);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addMutation"])(endpoint, method, body, tempId);
    if (endpoint.startsWith("/api/beneficiaries")) {
        const result = await applyBeneficiariesOptimistic(method, endpoint, body, tempId);
        if (result) return result;
    }
    if (endpoint.startsWith("/api/mobile/deliveries")) {
        return await applyDeliveriesOptimistic(body);
    }
    if (endpoint.startsWith("/api/mobile/menu-plans/execute")) {
        return await applyMenuPlansOptimistic(body);
    }
    if (endpoint.startsWith("/api/mobile/inventory/movements")) {
        return await applyInventoryOptimistic(body);
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success("Operación registrada localmente.");
    notifyOfflineMutationsUpdated();
    return {
        ok: true,
        message: "Operación registrada localmente."
    };
}
async function handleAuthError(res, clearAuth) {
    if (res.status === 401 && navigator.onLine) {
        clearAuth();
        if ("TURBOPACK compile-time truthy", 1) window.location.href = "/login";
        throw new Error("Sesión expirada. Ingresa nuevamente.");
    }
    throw new Error("Sin conexión. No se pudo validar la sesión.");
}
async function tryCacheFallback(cacheKey) {
    const cached = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCache"])(cacheKey);
    if (cached) {
        console.log("[useApi] Fallo de red. Sirviendo desde caché local:", cacheKey);
        return cached;
    }
    return null;
}
async function serveOfflineOrEnqueue(cacheKey, endpoint, fetchOpts, isGet) {
    if (isGet) {
        const cached = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCache"])(cacheKey);
        if (cached) {
            console.log("[useApi] Servido desde caché local (offline):", cacheKey);
            return cached;
        }
        throw new Error("Sin conexión. No hay datos locales guardados para esta vista.");
    }
    return await handleOfflineMutation(endpoint, fetchOpts);
}
async function parseErrorMessage(res) {
    const body = await res.json().catch(()=>({}));
    return body.message ?? body.error ?? `Error ${res.status}`;
}
async function fetchAndHandle(url, fetchOpts, headers, cacheKey, isGet, clearAuth, endpoint) {
    const res = await fetch(url, {
        ...fetchOpts,
        headers
    });
    if (res.status === 401) {
        return await handleAuthError(res, clearAuth);
    }
    if (!res.ok) {
        throw new Error(await parseErrorMessage(res));
    }
    const data = await res.json();
    if (isGet) await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setCache"])(cacheKey, data);
    return data;
}
function useApi() {
    _s();
    const token = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"])({
        "useApi.useAuthStore[token]": (s)=>s.token
    }["useApi.useAuthStore[token]"]);
    const clearAuth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"])({
        "useApi.useAuthStore[clearAuth]": (s)=>s.clearAuth
    }["useApi.useAuthStore[clearAuth]"]);
    const request = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useApi.useCallback[request]": async (endpoint, opts = {})=>{
            const { params, ...fetchOpts } = opts;
            const url = buildUrl(endpoint, params);
            const cacheKey = buildCacheKey(endpoint, params);
            const isGet = isGetRequest(fetchOpts.method);
            const online = isOnline();
            if (!online) {
                return serveOfflineOrEnqueue(cacheKey, endpoint, fetchOpts, isGet);
            }
            const headers = buildRequestHeaders(fetchOpts, token);
            try {
                return await fetchAndHandle(url.toString(), fetchOpts, headers, cacheKey, isGet, clearAuth, endpoint);
            } catch (err) {
                if (isGet) {
                    const cached = await tryCacheFallback(cacheKey);
                    if (cached) return cached;
                } else if (err instanceof TypeError && err.message === "Failed to fetch") {
                    return await handleOfflineMutation(endpoint, fetchOpts);
                }
                if (err instanceof TypeError && err.message === "Failed to fetch") {
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Sin conexión. Revisa tu red e intenta de nuevo.");
                    throw new Error("Sin conexión al servidor");
                }
                throw err;
            }
        }
    }["useApi.useCallback[request]"], [
        token,
        clearAuth
    ]);
    const get = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useApi.useCallback[get]": (endpoint, params)=>request(endpoint, {
                params
            })
    }["useApi.useCallback[get]"], [
        request
    ]);
    return {
        request,
        get
    };
}
_s(useApi, "rUBNZTBTR+a4xjWRFXMoBwCmXps=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$auth$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/mobile/alertas/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AlertasPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$triangle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertTriangle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/triangle-alert.js [app-client] (ecmascript) <export default as AlertTriangle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/clock.js [app-client] (ecmascript) <export default as Clock>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wifi$2d$off$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__WifiOff$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/wifi-off.js [app-client] (ecmascript) <export default as WifiOff>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$package$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Package$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/package.js [app-client] (ecmascript) <export default as Package>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/trash-2.js [app-client] (ecmascript) <export default as Trash2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/skeleton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/use-api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/indexed-db.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
function AlertasPage() {
    _s();
    const { get } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApi"])();
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [alertas, setAlertas] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const fetchAlertas = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AlertasPage.useCallback[fetchAlertas]": async ()=>{
            try {
                let serverAlertas = [];
                const isOffline = typeof navigator !== "undefined" && !navigator.onLine;
                if (!isOffline) {
                    const data = await get("/api/mobile/alerts");
                    serverAlertas = (data.items ?? []).map({
                        "AlertasPage.useCallback[fetchAlertas]": (a)=>({
                                id: a.id,
                                tipo: a.tipo,
                                titulo: a.titulo,
                                descripcion: a.descripcion,
                                fecha: a.fecha
                            })
                    }["AlertasPage.useCallback[fetchAlertas]"]);
                }
                // Obtener las mutaciones fallidas locales de IndexedDB
                const localFailed = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFailedMutations"])();
                const mappedLocal = localFailed.map({
                    "AlertasPage.useCallback[fetchAlertas].mappedLocal": (fm)=>{
                        const isBeneficiary = fm.path.startsWith("/api/beneficiaries");
                        const isDelivery = fm.path.startsWith("/api/mobile/deliveries");
                        const isMenu = fm.path.startsWith("/api/mobile/menu-plans");
                        const isInventory = fm.path.startsWith("/api/mobile/inventory");
                        let label = "Operación fallida";
                        let details = "";
                        if (isBeneficiary && fm.body) {
                            label = `Error al registrar beneficiario: ${fm.body.firstName || ""} ${fm.body.lastName || ""}`.trim();
                            details = `Beneficiario (DNI: ${fm.body.dni})`;
                        } else if (isDelivery && fm.body) {
                            label = `Error al registrar ración: ${fm.body.dishName || "Almuerzo"}`;
                            details = `Entrega (${fm.body.beneficiaryIds?.length || 0} personas)`;
                        } else if (isMenu && fm.body) {
                            label = `Error al planificar menú: ${fm.body.dishName || ""}`;
                            details = `Menú (${fm.body.servings || 0} raciones)`;
                        } else if (isInventory && fm.body) {
                            label = `Error en movimiento de almacén`;
                            details = `Insumo ID: ${fm.body.supplyItemId || ""}`;
                        }
                        return {
                            id: `local-failed-${fm.id}`,
                            tipo: "sincronizacion",
                            titulo: label,
                            descripcion: `${details ? details + " — " : ""}Conflicto de sincronización: ${fm.errorMessage}`,
                            fecha: "Error local",
                            isLocalConflict: true,
                            localId: fm.id,
                            originalPath: fm.path
                        };
                    }
                }["AlertasPage.useCallback[fetchAlertas].mappedLocal"]);
                setAlertas([
                    ...mappedLocal,
                    ...serverAlertas
                ]);
            } catch (err) {
                // Si estamos offline y falla, mostramos al menos las fallas locales
                const localFailed = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFailedMutations"])();
                const mappedLocal = localFailed.map({
                    "AlertasPage.useCallback[fetchAlertas].mappedLocal": (fm)=>({
                            id: `local-failed-${fm.id}`,
                            tipo: "sincronizacion",
                            titulo: "Conflicto local de sincronización",
                            descripcion: fm.errorMessage,
                            fecha: "Error local",
                            isLocalConflict: true,
                            localId: fm.id,
                            originalPath: fm.path
                        })
                }["AlertasPage.useCallback[fetchAlertas].mappedLocal"]);
                setAlertas(mappedLocal);
                if (typeof navigator !== "undefined" && navigator.onLine) {
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("Error al cargar alertas");
                }
            } finally{
                setLoading(false);
            }
        }
    }["AlertasPage.useCallback[fetchAlertas]"], [
        get
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AlertasPage.useEffect": ()=>{
            fetchAlertas();
            window.addEventListener("online", fetchAlertas);
            window.addEventListener("offline", fetchAlertas);
            window.addEventListener("pwa-sync-completed", fetchAlertas);
            window.addEventListener("offline-failed-mutations-updated", fetchAlertas);
            return ({
                "AlertasPage.useEffect": ()=>{
                    window.removeEventListener("online", fetchAlertas);
                    window.removeEventListener("offline", fetchAlertas);
                    window.removeEventListener("pwa-sync-completed", fetchAlertas);
                    window.removeEventListener("offline-failed-mutations-updated", fetchAlertas);
                }
            })["AlertasPage.useEffect"];
        }
    }["AlertasPage.useEffect"], [
        fetchAlertas
    ]);
    const icono = (tipo)=>{
        switch(tipo){
            case "vencimiento":
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__["Clock"];
            case "bajo_stock":
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$package$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Package$3e$__["Package"];
            case "sincronizacion":
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wifi$2d$off$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__WifiOff$3e$__["WifiOff"];
            default:
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$triangle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertTriangle$3e$__["AlertTriangle"];
        }
    };
    const color = (tipo)=>{
        switch(tipo){
            case "vencimiento":
                return "border-highlight bg-highlight/10 text-highlight-foreground";
            case "bajo_stock":
                return "border-destructive bg-destructive/10 text-destructive";
            case "sincronizacion":
                return "border-status-pending/30 bg-status-pending/10 text-status-pending";
            default:
                return "border-border bg-muted text-muted-foreground";
        }
    };
    const getAlertHref = (a)=>{
        if (a.isLocalConflict && a.originalPath) {
            if (a.originalPath.startsWith("/api/beneficiaries")) {
                return "/mobile/padron";
            }
            if (a.originalPath.startsWith("/api/mobile/inventory")) {
                return "/mobile/inventario";
            }
        }
        const normMsg = (a.descripcion + " " + a.titulo).toLowerCase();
        if (a.tipo === "sincronizacion" || normMsg.includes("beneficiario") || normMsg.includes("padrón") || normMsg.includes("dni")) {
            return "/mobile/padron";
        }
        return "/mobile/inventario";
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-4 p-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-xl font-bold text-foreground",
                                children: "Alertas"
                            }, void 0, false, {
                                fileName: "[project]/src/app/mobile/alertas/page.tsx",
                                lineNumber: 171,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm text-muted-foreground",
                                children: [
                                    alertas.length,
                                    " ",
                                    alertas.length === 1 ? "notificación" : "notificaciones",
                                    typeof navigator !== "undefined" && !navigator.onLine && " (Modo offline)"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/mobile/alertas/page.tsx",
                                lineNumber: 172,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/mobile/alertas/page.tsx",
                        lineNumber: 170,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$triangle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertTriangle$3e$__["AlertTriangle"], {
                        className: "h-6 w-6 text-highlight-foreground"
                    }, void 0, false, {
                        fileName: "[project]/src/app/mobile/alertas/page.tsx",
                        lineNumber: 177,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/mobile/alertas/page.tsx",
                lineNumber: 169,
                columnNumber: 7
            }, this),
            loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-3",
                children: [
                    1,
                    2,
                    3
                ].map((i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Skeleton"], {
                        className: "h-[72px] rounded-xl"
                    }, i, false, {
                        fileName: "[project]/src/app/mobile/alertas/page.tsx",
                        lineNumber: 183,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/app/mobile/alertas/page.tsx",
                lineNumber: 181,
                columnNumber: 9
            }, this) : alertas.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col items-center py-16 text-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$triangle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertTriangle$3e$__["AlertTriangle"], {
                        className: "mb-3 h-12 w-12 text-muted-foreground/30"
                    }, void 0, false, {
                        fileName: "[project]/src/app/mobile/alertas/page.tsx",
                        lineNumber: 188,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-muted-foreground",
                        children: "No hay alertas pendientes"
                    }, void 0, false, {
                        fileName: "[project]/src/app/mobile/alertas/page.tsx",
                        lineNumber: 189,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/mobile/alertas/page.tsx",
                lineNumber: 187,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-3",
                children: alertas.map((a)=>{
                    const Icon = icono(a.tipo);
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex items-start justify-between gap-3 rounded-xl border p-4 transition active:scale-[0.99]", color(a.tipo)),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: getAlertHref(a),
                                className: "flex flex-1 items-start gap-3 min-w-0",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                        className: "mt-0.5 h-5 w-5 shrink-0"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/mobile/alertas/page.tsx",
                                        lineNumber: 204,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "min-w-0 flex-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex flex-wrap items-center gap-1.5",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-sm font-semibold text-foreground tracking-tight leading-tight",
                                                        children: a.titulo
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/mobile/alertas/page.tsx",
                                                        lineNumber: 207,
                                                        columnNumber: 23
                                                    }, this),
                                                    a.isLocalConflict && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "inline-flex items-center rounded-full bg-destructive/25 px-2 py-0.5 text-[9px] font-bold text-destructive-foreground uppercase tracking-wide",
                                                        children: "Conflict local"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/mobile/alertas/page.tsx",
                                                        lineNumber: 209,
                                                        columnNumber: 25
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/mobile/alertas/page.tsx",
                                                lineNumber: 206,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-xs text-muted-foreground mt-1 leading-snug",
                                                children: a.descripcion
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/mobile/alertas/page.tsx",
                                                lineNumber: 214,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/mobile/alertas/page.tsx",
                                        lineNumber: 205,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/mobile/alertas/page.tsx",
                                lineNumber: 203,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col items-end justify-between self-stretch shrink-0 min-h-[40px] pl-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-[10px] font-medium uppercase text-muted-foreground",
                                        children: a.fecha
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/mobile/alertas/page.tsx",
                                        lineNumber: 219,
                                        columnNumber: 19
                                    }, this),
                                    a.isLocalConflict && a.localId !== undefined && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: async (e)=>{
                                            e.preventDefault();
                                            e.stopPropagation();
                                            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$indexed$2d$db$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteFailedMutation"])(a.localId);
                                            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success("Conflicto descartado");
                                            fetchAlertas();
                                        },
                                        className: "text-muted-foreground hover:text-destructive active:scale-90 transition-transform p-1 cursor-pointer",
                                        title: "Descartar conflicto",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"], {
                                            className: "h-4 w-4"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/mobile/alertas/page.tsx",
                                            lineNumber: 232,
                                            columnNumber: 23
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/mobile/alertas/page.tsx",
                                        lineNumber: 221,
                                        columnNumber: 21
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/mobile/alertas/page.tsx",
                                lineNumber: 218,
                                columnNumber: 17
                            }, this)
                        ]
                    }, a.id, true, {
                        fileName: "[project]/src/app/mobile/alertas/page.tsx",
                        lineNumber: 196,
                        columnNumber: 15
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/src/app/mobile/alertas/page.tsx",
                lineNumber: 192,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/mobile/alertas/page.tsx",
        lineNumber: 168,
        columnNumber: 5
    }, this);
}
_s(AlertasPage, "88lZVxJ46D5CyQgj8vccq9DP7Og=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$use$2d$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApi"]
    ];
});
_c = AlertasPage;
var _c;
__turbopack_context__.k.register(_c, "AlertasPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/lucide-react/dist/esm/icons/clock.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Clock
]);
/**
 * @license lucide-react v1.8.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "circle",
        {
            cx: "12",
            cy: "12",
            r: "10",
            key: "1mglay"
        }
    ],
    [
        "path",
        {
            d: "M12 6v6l4 2",
            key: "mmk7yg"
        }
    ]
];
const Clock = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("clock", __iconNode);
;
}),
"[project]/node_modules/lucide-react/dist/esm/icons/clock.js [app-client] (ecmascript) <export default as Clock>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Clock",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/clock.js [app-client] (ecmascript)");
}),
]);

//# sourceMappingURL=_02_4c-b._.js.map