(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_0qf4l8-._.js","static/chunks/node_modules_0..hxqp._.js"],
    source: "dynamic"
});
