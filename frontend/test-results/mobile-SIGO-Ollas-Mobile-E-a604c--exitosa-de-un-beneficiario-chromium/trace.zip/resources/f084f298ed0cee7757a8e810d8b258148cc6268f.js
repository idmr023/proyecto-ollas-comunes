(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0t8~q_c._.css","static/chunks/src_12qof0c._.js","static/chunks/node_modules_0s-suqa._.js"],
    source: "dynamic"
});
