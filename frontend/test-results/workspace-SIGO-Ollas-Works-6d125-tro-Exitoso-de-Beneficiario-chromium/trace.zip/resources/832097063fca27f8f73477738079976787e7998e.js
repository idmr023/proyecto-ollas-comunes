(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_005ek7b._.js","static/chunks/node_modules_@radix-ui_react-label_dist_index_mjs_06786yg._.js"],
    source: "dynamic"
});
